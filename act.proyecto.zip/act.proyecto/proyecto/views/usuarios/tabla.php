<?php 
/* configurar el paginado */
$registroPorPagina = 5;
//obtener el numero de pagina
$pagina = isset($_GET['page']) ? (int) $_GET['page'] : 1;
//evitar que se utilicen paginas menores que 1
if($pagina < 1){
    $pagina = 1;
}
//contar total de registros
$sqlTotal = "SELECT COUNT(*) AS total FROM usuarios AS u INNER JOIN roles AS r ON u.idrol=r.idrol";
$dataTotal = CRUD($sqlTotal, "S");
$totalRegistros = $dataTotal[0]['total']?? 0;

//calcular total de paginas
$totalPaginas = ceil($totalRegistros/$registroPorPagina);
//validar la ultima pagina
if($totalPaginas > 0 && $pagina > $totalPaginas){
    $pagina = $totalPaginas;
}

//OFFSET
$offset = ($pagina -1) * $registroPorPagina;

 $sql = "SELECT *
FROM usuarios AS u 
INNER JOIN roles AS r ON u.idrol=r.idrol ORDER BY u.idusuario ASC LIMIT $registroPorPagina OFFSET $offset";

$dataUsuarios = CRUD($sql,"S");
?>
<a href="" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#ModalInsertUser">
            <i class="fa-solid fa-user-plus"></i>
            </a>
            <hr>
            <div class="table-responsive">
            <table class="table table-borderless table-bordered table-hover 
            table-sm" border="1" style="border-collapse: collapse;">

            <thead class="table-dark p-3">
                <tr>
                    <th class="ccv">ID</th>
                    <th class="ccv">Usuario</th>
                    <th class="ccv">Email</th>
                    <th class="ccv">Rol</th>
                    <th class="ccv">Estado</th>
                    <th class="ccv" colspan="3">Acciones</th>
                </tr>
            </thead>
            <tbody>
<?php foreach($dataUsuarios as $result): ?>
<tr>
    <td><?= $idusuario = $result['idusuario'] ?></td>
    <td><?= $result['usuario'] ?></td>
    <td><?= $result['email'] ?></td>
    <td><?= $result['rol'] ?></td>
    <td><?= ($result['estado'] == 1)? 'Activo': 'Inactivo'; ?></td>
    <td></td>
    <td></td>
    <td></td>
</tr>


<?php endforeach; ?>
            </tbody>
            </table>
            <?php if($totalRegistros >0):?>
                <div class="d-flex justify-content-between align-items-center mt-3">
                    <div><small class="text-muted">
                        pagina <strong><?= $pagina; ?></strong> de <strong><?= $totalPaginas; ?></strong> |total de 
                        registros <strong><?= $totalRegistros; ?></strong>
                    </small>
                </div>
                <nav aria-label="Paginacion de Usuarios">
                    <ul class="pagination pagination-sm mb-0">
                        <!--Boton anterior o regresar-->
                        <?php if($pagina > 1):?> 
                            <li class="page-item">
                                <a href="?page=<?= $pagina -1; ?>" class="page-link">
                                    <i class="fa-solid fa-angle-left"></i> Anterior
                                </a>
                            </li> 
                        <?php else:?> 
                              <li class="page-item disabled">
                                <span class="page-link">
                                    <i class="fa-solid fa-angle-left"></i> Anterior
                                </span>
                            </li> 
                        <?php endif?>
                        <!--Boton con numero de paginas-->
                        <?php for($i = 1; $i <= $totalPaginas; $i++):?> 
                        <?php if($i == $pagina):?>
                            <li class="page-item active">
                                <span class="page-link">
                                   <?= $i; ?>
                                </span>
                            </li>
                         <?php else: ?>
                         <li class="page-item">
                            <a href="?page=<?= $i ?>" class="page-link">
                                <?= $i; ?>
                            </a>
                        </li>
                         <?php endif;?>
                         <?php endfor;?>
                         <!--Boton siguiente-->
                         <?php if($pagina < $totalPaginas):?>
                            <li class="page-item">
                                <a href="?page=<?= $pagina + 1; ?>" class="page-link">
                                    Siguiente <i class="fa-solid fa-angle-right"></i>
                                </a>
                            </li>

                         <?php else:?> 
                             <li class="page-item disabled">
                                <span class="page-link">
                                    Siguiente <i class="fa-soli fa-angle-right"></i>
                         </span>
                            </li> 

                         <?php endif;    ?>      
                    </ul>
                </nav>
                </div> 
            <?php else:?>
            <?php endif ?>
            </div>
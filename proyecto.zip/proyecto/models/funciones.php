<?php
class Procesos{
    // GDU = Get Data User
    public function GDU($user,$tabla,$campo){
        $row = [];
        $modelo = new Conexion();
        $conexion = $modelo->getConexion();
        $arg = ":".$campo; // :usuario O :email
        $query = "SELECT * FROM usuarios WHERE $campo = $arg OR email = $arg";
    } 
}